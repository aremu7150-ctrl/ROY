module.exports = require("./automation");
