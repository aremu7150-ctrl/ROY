module.exports = require("./hangman");
